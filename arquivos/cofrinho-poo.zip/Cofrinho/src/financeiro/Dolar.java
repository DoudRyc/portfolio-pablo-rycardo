package financeiro;

public class Dolar extends Moeda {

    // Construtor repassa o valor para a classe mãe
    public Dolar(double valor, String tipo) {
        super(valor, tipo);
    }

    // Converte dólar para real usando o valor definido no trabalho
    @Override
    double converter() {
        return getValor() * 5.36; // cotação usada no trabalho
    }

    @Override
    public String toString() {
        return "Dolar [converter()=" + converter() + ", Valor()=" + getValor() + "]";
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;

        // Verifica se realmente é um objeto Dolar
        if (getClass() != obj.getClass())
            return false;

        return true;
    }
}
