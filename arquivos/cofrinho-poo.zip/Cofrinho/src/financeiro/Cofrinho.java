package financeiro;

import java.util.ArrayList;

public class Cofrinho {

    // Lista onde todas as moedas adicionadas ficam guardadas
    private ArrayList<Moeda> listaDeMoedas = new ArrayList<Moeda>();
        
    // Método para colocar uma moeda dentro do cofrinho
    public void adicionar(Moeda m) {
        listaDeMoedas.add(m);
    }
    
    // Remove uma moeda específica (usa equals para comparar)
    public void remover(Moeda m) {
        // Se não tiver nada no cofre, não tem o que remover
        if(listaDeMoedas.isEmpty()) {
            System.out.println("Sem moedas no cofre");
            return;
        } 
        // Se tiver, tenta remover a moeda informada
        listaDeMoedas.remove(m);
    }
    
    // Mostra todas as moedas que estão guardadas
    public void listar() {
        for(Moeda m : listaDeMoedas) {
            m.info(); // info() mostra o tipo e o valor da moeda
        }
    }
    
    // Soma o valor convertido de todas as moedas para real
    public void totalConvertido() {
        double total = 0;

        // Percorre a lista e vai somando o valor convertido de cada uma
        for (Moeda moeda : listaDeMoedas) {
            total += moeda.converter();
        }

        // Mostra o resultado final
        System.out.println("Total em Real: R$" + total);
    }
    
    // Apenas imprime o menu principal do cofrinho
    public void menuCofrinho() {
        System.out.println("----------------");
        System.out.println("Menu do Cofrinho");
        System.out.println("----------------");
        System.out.println("Digite a opção desejada:");
        System.out.println("1 - Adicionar Moedas");
        System.out.println("2 - Remover Moedas");
        System.out.println("3 - Listar Moedas");
        System.out.println("4 - Mostrar Total em Real");
        System.out.println("0 - Sair");
        System.out.println("----------------");
    }
}
