package financeiro;

public class Euro extends Moeda {

    // Construtor repassando para a classe mãe
    public Euro(double valor, String tipo) {
        super(valor, tipo);
    }

    // Conversão de euro para real com a cotação usada no trabalho
    @Override
    double converter() {
        return getValor() * 6.22;
    }

    @Override
    public String toString() {
        return "Euro [converter()=" + converter() + ", Valor()=" + getValor() + "]";
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;

        // Garante que o objeto realmente é um Euro
        if (getClass() != obj.getClass())
            return false;

        return true;
    }
}
