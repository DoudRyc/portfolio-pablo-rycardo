package financeiro;

import java.util.Objects;

public abstract class Moeda {

    // Valor que aquela moeda representa
    protected double valor;

    // Nome ou tipo da moeda (Real, Dolar, Euro)
    protected String tipo;
    
    // Construtor base que todas as moedas usam
    protected Moeda(double valor, String tipo) {
        this.valor = valor;
        this.tipo = tipo;
    }

    // Getter do valor da moeda
    public double getValor() {
        return valor;
    }

    // Setter para alterar o valor, caso necessário
    public void setValor(double valor) {
        this.valor = valor;
    }

    // Cada moeda converte de um jeito, então esse método é abstrato
    abstract double converter();
    
    // Exibe informações simples sobre a moeda
    public void info() {
        System.out.println("---------------");
        System.out.println("Moeda: " + tipo);
        System.out.println("Valor: " + getValor());
        System.out.println("---------------");
    }
    
    // Menu para escolher o tipo de moeda
    public static void menuMoeda() {
        System.out.println("Digite a moeda: ");
        System.out.println("1 - Dólar");
        System.out.println("2 - Euro");
        System.out.println("3 - Real");
    }

    // hashCode e equals servem para comparar moedas ao remover
    @Override
    public int hashCode() {
        return Objects.hash(tipo, valor);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;

        // Moedas só são iguais se forem da MESMA classe
        if (getClass() != obj.getClass())
            return false;

        Moeda other = (Moeda) obj;

        // Compara o tipo e o valor
        return Objects.equals(tipo, other.tipo)
                && Double.doubleToLongBits(valor) == Double.doubleToLongBits(other.valor);
    }
}
