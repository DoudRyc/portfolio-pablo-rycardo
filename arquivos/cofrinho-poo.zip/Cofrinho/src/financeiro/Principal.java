package financeiro;

import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {

        // Scanner para ler entradas do usuário (teclado)
        Scanner teclado = new Scanner(System.in);

        // Instancia do cofrinho que guarda as moedas
        Cofrinho cofre = new Cofrinho();

        // Variável que será usada para criar/receber objetos Moeda
        Moeda moeda = null;

        // Variáveis de controle do menu e valores lidos
        int opcao;           // opção do menu principal
        int opcaoMoeda = 0;  // escolha do tipo de moeda (1,2,3)
        double valor;        // valor da moeda a ser inserida/removida
        String tipo;         // texto que descreve o tipo (apenas informativo)

        // Mostra o menu assim que o programa inicia
        cofre.menuCofrinho();
        opcao = teclado.nextInt();

        // Loop principal: repete até o usuário escolher 0 (sair)
        while (opcao != 0) {

            // Reseta a variável de escolha da moeda antes de pedir ao usuário
            opcaoMoeda = 0;

            switch (opcao) {
                case 1:
                    // Adicionar moeda
                    System.out.println("Opção 1 selecionada: Adicionar Moedas");

                    // Garante que o usuário escolha uma opção válida (1,2 ou 3)
                    while (opcaoMoeda > 3 || opcaoMoeda == 0) {
                        Moeda.menuMoeda();          // mostra as opções de moeda
                        opcaoMoeda = teclado.nextInt();
                    }

                    // Dependendo da escolha, pede o valor e cria o objeto correspondente
                    if (opcaoMoeda == 1) { // Dólar
                        System.out.println("Digite o Valor a ser adicionado");
                        valor = teclado.nextDouble();   // lê valor como double
                        tipo = "Dolar";                 // texto informativo
                        moeda = new Dolar(valor, tipo); // cria objeto Dolar

                    } else if (opcaoMoeda == 2) { // Euro
                        System.out.println("Digite o Valor a ser adicionado");
                        valor = teclado.nextDouble();
                        tipo = "Euro";
                        moeda = new Euro(valor, tipo);

                    } else { // Real (opcaoMoeda == 3)
                        System.out.println("Digite o Valor a ser adicionado");
                        valor = teclado.nextDouble();
                        tipo = "Real";
                        moeda = new Real(valor, tipo);
                    }

                    // Adiciona a moeda criada no cofrinho
                    cofre.adicionar(moeda);
                    break;

                case 2:
                    // Remover moeda
                    System.out.println("Opção 2 selecionada: Remover Moedas");

                    // Mesma verificação para garantir tipo válido
                    while (opcaoMoeda > 3 || opcaoMoeda == 0) {
                        Moeda.menuMoeda();
                        opcaoMoeda = teclado.nextInt();
                    }

                    // Cria um objeto temporário com o valor informado
                    // e tenta removê-lo do cofrinho (usa equals)
                    if (opcaoMoeda == 1) { // Dólar
                        System.out.println("Digite o Valor a ser removido");
                        valor = teclado.nextDouble();
                        tipo = "Dolar";
                        moeda = new Dolar(valor, tipo);

                    } else if (opcaoMoeda == 2) { // Euro
                        System.out.println("Digite o Valor a ser removido");
                        valor = teclado.nextDouble();
                        tipo = "Euro";
                        moeda = new Euro(valor, tipo);

                    } else { // Real
                        System.out.println("Digite o Valor a ser removido");
                        valor = teclado.nextDouble();
                        tipo = "Real";
                        moeda = new Real(valor, tipo);
                    }

                    // Chama o método de remoção do cofrinho
                    cofre.remover(moeda);
                    break;

                case 3:
                    // Listar todas as moedas do cofrinho
                    System.out.println("Opção 3 selecionada: Listar Moedas");
                    cofre.listar();
                    break;

                case 4:
                    // Exibir o total convertido para Real
                    System.out.println("Opção 4 selecionada: Mostrar Total em Real");
                    cofre.totalConvertido();
                    break;

                default:
                    // Caso o usuário digite algo inválido
                    System.out.println("Opção inválida");
                    break;
            }

            // Depois de executar a ação, mostra o menu de novo para nova escolha
            cofre.menuCofrinho();
            opcao = teclado.nextInt();
        }

        // Mensagem de finalização e fechamento do scanner
        System.out.println("Encerrando...");
        System.out.println("Até mais!");
        teclado.close();
    }
}
