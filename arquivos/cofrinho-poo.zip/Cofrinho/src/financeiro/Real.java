package financeiro;

public class Real extends Moeda {

    // Construtor repassando para a classe mãe
    public Real(double valor, String tipo) {
        super(valor, tipo);
    }

    // Real não precisa converter nada, já está em Real
    @Override
    double converter() {
        return getValor();
    }

    // Métodos gerados automaticamente (não essenciais para o trabalho)
    @Override
    public String toString() {
        return "Real [converter()=" + converter() + ", Valor()=" + getValor() + "]";
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;

        // Confirma que o objeto realmente é um Real
        if (getClass() != obj.getClass())
            return false;

        return true;
    }
}
